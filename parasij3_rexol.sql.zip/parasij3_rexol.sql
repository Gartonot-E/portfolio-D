-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 04 2021 г., 10:54
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `parasij3_rexol`
--

-- --------------------------------------------------------

--
-- Структура таблицы `photo`
--
-- Создание: Май 26 2021 г., 17:01
-- Последнее обновление: Июн 27 2021 г., 10:22
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE `photo` (
  `id` int(11) UNSIGNED NOT NULL,
  `src` varchar(255) NOT NULL,
  `likes` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `photo`
--

INSERT INTO `photo` (`id`, `src`, `likes`, `date`) VALUES
(62, '48742d163923496499c3be7e0e91dd75.png', '231', '31-05-2021 22:30'),
(56, '6e8024ec26c292f258ec30f01e0392dc.png', '233', '26-05-2021 13:29'),
(73, 'ff6ca0697f204195b272e50f12660b9b.png', '1', '18-06-2021 22:33'),
(61, '3b87f097c2bf221849c0e867cb62426a.png', '232', '31-05-2021 22:29'),
(60, '3541d514c6351bb8b74d06e736eb22ec.png', '236', '31-05-2021 22:29'),
(63, '3d46627c12d2fe0e1d24a2d1f5271a30.png', '230', '31-05-2021 22:31'),
(71, 'a1fb5c4a05511a579b74fea6adca7251.png', '1', '18-06-2021 22:26'),
(72, '30fe48d428c42d704eb829b9ed719266.png', '2', '18-06-2021 22:31');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `photo`
--
ALTER TABLE `photo`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
